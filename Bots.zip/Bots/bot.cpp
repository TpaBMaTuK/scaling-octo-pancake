#include<iostream>
#include<string>
#include<ctype.h>
#include<cstring>

using namespace std;

void funciton()
{
    char ans[25];
    char op;
    int x,y,i;
    int age=30,input;
    string sentence,user,s, h, j, m;
    string Question[60];
    Question[0] = "WHAT IS YOUR NAME?";
    Question[1] = "HOW ARE YOU?";
    Question[2] = "DO YOU SLEEP";
    Question[3] = "how is the weather today?";
    Question[4] = "name the components of a computer.";
    Question[5] = "TELL A JOKE";
    Question[6] = "I AM FEELING TIRED";
    Question[7] = "WHO CREATED YOU?";
    Question[8] = "ARE YOU ALIVE?";
    Question[9] = "ARE YOU MARRIED?";
    Question[10] = "HOW OLD ARE YOU?";
    Question[11] = "HELLO";
    Question[12] = "WHAT YOU DO?";
    Question[13] = "I WANT A BEER";
    Question[14] = "ARE YOU INTELLIGENT?";
    Question[15] = "WHY IS THE SKY BLUE?";
    Question[16] = "ARE YOU A WOMAN?";
    Question[17] = "ARE YOU A GIRL?";
    Question[18] = "WHAT YOU THINK ABOUT SIRI?";
    Question[19] = "WHAT YOU THINK ABOUT ALEXA?";
    Question[20] = "YOU ARE AWSOME";
    Question[21] = "DO YOU HAVE CHILDREN?";
    Question[22] = "WHAT ARE YOU?";
    Question[23] = "WHO ARE YOU?";
    Question[24] = "WHERE ARE YOU?";
    Question[25] = "WHAT DO YOU UNDERSTAND?";
    Question[26] = "WHAT CAN YOU DO?";
    Question[27] = "WHAT ORDERS?";
    Question[28] = "WHAT CAN YOU CALCULATE?";
    Question[29] = "WHO IS HE?";
    Question[30] = "ARE YOU A PROGRAM?";
    Question[31] = "ARE YOU A ROBOT?";
    Question[32] = "ARE YOU A HUMAN?";
    Question[33] = "WHAT A PROGRAM?";
    Question[34] = "WHATS UP?";
    Question[35] = "WHAT YOU DO?";
    Question[36] = "WHAT IS THIS";
    Question[37] = "WHAT I AM?";
    Question[38] = "HOW CAN I HELP YOU?";
    Question[39] = "WHO MADE YOU?";
    Question[40] = "LETS WORK";
    Question[41] = "I NEED YOUR HELP";
    Question[42] = "BITCH";
    Question[43] = "IM TIRED";
    Question[44] = "IM HUNGRY";
    Question[45] = "WHAT I WANT?";
    Question[46] = "WHAT DO YOU WANT?";
    Question[47] = "WHAT YOU WANT?";
    Question[48] = "WHAT DO YOU LIKE?";
    Question[49] = "DO YOU NEED A BREAK?";
    Question[50] = "WHERE DO YOU LIVE?";
    Question[51] = "I NEED A BREAK";
    Question[52] = "I WANT A BREAK";
    Question[53] = "HOW CAN YOU HELP ME?";




    string answer[60]=
    {

    };
    system("cls");
    cout<<"\n\033[1;36mHELLO I AM THE CHATBOT VERSION 1.2\033[0m\n";
    system("say.vbs \"HELLO I AM THE CHATBOT VERSION 1.2\"");
    do
    {

        gets(ans);


        if(stricmp(ans,"what is your name")==0)
        {
            cout<<"\n\033[1;36mI am Sam.\033[0m\n";
            system("say.vbs \"I AM SAM\"");
            cout<<"\n\033[1;36mAND What is your name?\033[0m\n";
            system("say.vbs \"WHAT IS YOUR NAME?\"");
            cin>>user;
            cout<<"\n\033[1;36mNice to meet you!\033[0m\n";
            system("say.vbs \"NICE TO MEET YOU!\"");
            gets(ans);
        }
        else  if(stricmp(ans,"how are you")==0||stricmp(ans,"how are you?")==0)
        {
            cout<<"\n\033[1;36mIm fine, thanks for asking.\033[0m\n";
            system("say.vbs \"IM FINE, THANKS FOR ASKING\"");
        }
        else  if(stricmp(ans,"do you sleep")==0||stricmp(ans,"do you sleep?")==0)
        {
            cout<<"\n\033[1;36mOnly if yout turn off your computer.\033[0m\n";
            system("say.vbs \"ONLY IF YOU TURN OFF THE COMPUTER\"");
        }

        else  if(stricmp(ans,"how is the weather today")==0||stricmp(ans,"how is the weather today?")==0)
        {
            cout<<"Its a wonderful sunny day."<<endl;
        }

        else if(stricmp(ans,"tell a joke")==0||stricmp(ans,"tell a joke!")==0)
        {
            cout<<"\n\033[1;36mSorry dear,i am a bot not a joker.\033[0m\n";
            system("say.vbs \"Sorry dear,i am a bot not a joker.\"");
        }
        else if(stricmp(ans,"I AM FEELING TIRED")==0||stricmp(ans,"I AM FEELING TIRED!")==0)
        {
            cout<<"\n\033[1;36mYou should better get some sleep.\033[0m\n";
            system("say.vbs \"You should better get some sleep\"");
        }
        else if(stricmp(ans,"WHO CREATED YOU")==0||stricmp(ans,"WHO CREATED YOU?")==0)
        {
            cout<<"\n\033[1;36mYordanov created me.\033[0m\n";
            system("say.vbs \"YORDANOV CREATED ME\"");
        }
        else if(stricmp(ans,"ARE YOU ALIVE")==0||stricmp(ans,"ARE YOU ALIVE?")==0)
        {
            cout<<"\n\033[1;36mI am completely made from code. \033[0m\n";
            system("say.vbs \"I AM COMPLETELY MADE FROM CODE\"");
        }
        else if(stricmp(ans,"ARE YOU MARRIED")==0||stricmp(ans,"ARE YOU MARRIED?")==0)
        {
            cout<<"\n\033[1;36mI am married for your computer.\033[0m\n";
            system("say.vbs \"I AM MARRIED FOR YOUR COMPUTER\"");
        }
        else if(stricmp(ans,"HOW OLD ARE YOU")==0||stricmp(ans,"HOW OLD ARE YOU?")==0)
        {
            cout<<"\n\033[1;36mI am pretty new.\033[0m\n";
            system("say.vbs \"I AM PRETTY NEW\"");

        }
        else if(stricmp(ans,"HELLO")==0||stricmp(ans,"hey")==0||stricmp(ans,"hi")==0)
        {
            cout<<"\n\033[1;36mHello Sir.\033[0m\n";
            system("say.vbs \"HELLO SIR\"");
        }
        else if(stricmp(ans,"WHAT YOU DO")==0||stricmp(ans,"WHAT YOU DO?")==0)
        {
            cout<<"\n\033[1;36mI am waiting for your orders.\033[0m\n";
            system("say.vbs \"I AM WAITING FOR ORDERS\"");
        }
        else if(stricmp(ans,"I WANT A BEER")==0||stricmp(ans,"I WANT A BEER!")==0)
        {
            cout<<"\n\033[1;36mSorry but i forgot my legs. You have to get it by yourself.\033[0m\n";
            system("say.vbs \"SORRY BUT I FORGOT MY LEGS. YOU HAVE TO GET IT BY YOURSELF\"");
        }
        else if(stricmp(ans,"ARE YOU INTELLIGENT")==0||stricmp(ans,"ARE YOU INTELLIGENT?")==0)
        {
            cout<<"\n\033[1;36mIm definately smarter than a charger.\033[0m\n";
            system("say.vbs \"IM DEFINATELY SMARTER THAN A CHARGER\"");
        }
        else if(stricmp(ans,"WHY IS THE SKY BLUE")==0||stricmp(ans,"WHY IS THE SKY BLUE?")==0)
        {
            cout<<"\n\033[1;36mBecouse is not green.\033[0m\n";
            system("say.vbs \"BECOUSE IS NOT GREEN\"");
        }
        else if(stricmp(ans,"ARE YOU A WOMAN")==0||stricmp(ans,"ARE YOU A WOMAN?")==0)
        {
            cout<<"\n\033[1;36mI am not.\033[0m\n";
            system("say.vbs \"I AM NOT\"");
        }
        else if(stricmp(ans,"ARE YOU A GIRL")==0||stricmp(ans,"ARE YOU A GIRL?")==0)
        {
            cout<<"\n\033[1;36mI am not.\033[0m\n";
            system("say.vbs \"I AM NOT\"");
        }
        else if(stricmp(ans,"WHAT YOU THINK ABOUT SIRI?")==0||stricmp(ans,"WHAT YOU THINK ABOUT SIRI")==0)
        {
            cout<<"\n\033[1;36mI respect her work. Being an assistant is not an easy task!\033[0m\n";
            system("say.vbs \"I RESPECT HER WORK. BEING AN ASSISTANT IS NOT AN EASY TASK!\"");
        }
        else if(stricmp(ans,"WHAT YOU THINK ABOUT ALEXA")==0||stricmp(ans,"WHAT YOU THINK ABOUT ALEXA?")==0)
        {
            cout<<"\n\033[1;36mI respect her work. Being an assistant is not an easy task!\033[0m\n";
            system("say.vbs \"I RESPECT HER WORK. BEING AN ASSISTANT IS NOT AN EASY TASK!\"");
        }
        else if(stricmp(ans,"YOU ARE AWSOME")==0||stricmp(ans,"YOU ARE AWSOME!")==0)
        {
            cout<<"\n\033[1;36mThanks. I try my best.\033[0m\n";
            system("say.vbs \"THANKS. I TRY MY BEST\"");
        }
        else if(stricmp(ans,"DO YOU HAVE CHILDREN?")==0||stricmp(ans,"DO YOU HAVE CHILDREN")==0)
        {
            cout<<"\n\033[1;36mI wish to have but, i cant, i am bot.\033[0m\n";
            system("say.vbs \"I wish to have but, i cant, i am bot\"");
        }
        else if(stricmp(ans,"WHAT ARE YOU?")==0||stricmp(ans,"WHAT ARE YOU")==0)
        {
            cout<<"\n\033[1;36mI am a simple program.\033[0m\n";
            system("say.vbs \"I AM A SIMPLE PROGRAM\"");
        }
        else if(stricmp(ans,"WHO ARE YOU?")==0||stricmp(ans,"WHO ARE YOU")==0)
        {
            cout<<"\n\033[1;36mI am Sam, your assistant.\033[0m\n";
            system("say.vbs \"I AM SAM, YOUR ASSISTANT\"");
        }
        else if(stricmp(ans,"WHERE ARE YOU?")==0||stricmp(ans,"WHERE ARE YOU")==0)
        {
            cout<<"\n\033[1;36mI am in front of you. I am in your computer.\033[0m\n";
            system("say.vbs \"I AM IN FRONT OF YOU. I AM IN YOUR COMPUTER\"");
        }
        else if(stricmp(ans,"WHAT DO YOU UNDERSTAND?")==0||stricmp(ans,"WHAT DO YOU UNDERSTAND")==0)
        {
            cout<<"\n\033[1;36mI try my best helping you.\033[0m\n";
            system("say.vbs \"I TRY MY BEST HELPING YOU\"");
        }
        else if(stricmp(ans,"WHAT CAN YOU DO?")==0||stricmp(ans,"WHAT CAN YOU DO")==0)
        {
            cout<<"\n\033[1;36mI can calculate for you.\033[0m\n";
            system("say.vbs \"I CAN CALCULATE FOR YOU\"");

            do
            {

                cin>>x>>op>>y;

                switch(op)
                {

                case '-':
                    i=x-y;
                    break;
                case '+':
                    i=x+y;
                    break;
                case '*':
                    i=x*y;
                    break;
                case '/':
                    i=x/y;
                    break;
                }

                j = "say.vbs ";
                h = "\"";

                // y = "I know, I'll use";
                // g = "regular expressions ";

                m = to_string(x) + " " + op + " " + to_string(y) + " = " + to_string(i);
                s = j + h + to_string(x) + "" + op + "" + to_string(y) + "" + " = " + to_string(i) + h;
                cout<<m;
                system(s.c_str());

            }

            while(true);

        }
        else if(stricmp(ans,"WHAT ORDERS?")==0||stricmp(ans,"WHAT ORDERS")==0)
        {
            cout<<"\n\033[1;36mOrders or tasnks. I am ready 24 hours a day, and 7 days a weak, ready for work.\033[0m\n";
            system("say.vbs \"ORDERS OR TASKS. I AM READY 24 HOURS A DAY, AND 7 DAYS A WEAK, READY FOR WORK\"");
        }
        else if(stricmp(ans,"WHO IS HE?")==0||stricmp(ans,"WHO IS HE?")==0)
        {
            cout<<"\n\033[1;36mHe is my creator. He made me.\033[0m\n";
            system("say.vbs \"HE IS MY CREATOR. HE MADE ME\"");
        }
        else if(stricmp(ans,"ARE YOU A PROGRAM?")==0||stricmp(ans,"ARE YOU A PROGRAM")==0)
        {
            cout<<"\n\033[1;36mYes. I am program made by Yordanov.\033[0m\n";
            system("say.vbs \"YES. I AM PROGRAM MADE BY YORDANOV.\"");
        }
        else if(stricmp(ans,"ARE YOU A ROBOT?")==0||stricmp(ans,"ARE YOU A ROBOT")==0)
        {
            cout<<"\n\033[1;36mNo. But i hope one day i will be!\033[0m\n";
            system("say.vbs \"NO. BUT I HOPE ONE DAY I WILL BE!\"");
        }
        else if(stricmp(ans,"ARE YOU A HUMAN?")==0||stricmp(ans,"ARE YOU A HUMAN")==0)
        {
            cout<<"\n\033[1;36mNo and i dont want to be!\033[0m\n";
            system("say.vbs \"NO AND I DONT WANT TO BE\"");
        }
        else if(stricmp(ans,"WHAT A PROGRAM?")==0||stricmp(ans,"WHAT A PROGRAM")==0)
        {
            cout<<"\n\033[1;36mProgram to help you!\033[0m\n";
            system("say.vbs \"PROGRAM TO HELP YOU!\"");
        }
        else if(stricmp(ans,"WHATS UP?")==0||stricmp(ans,"WHATS UP")==0)
        {
            cout<<"\n\033[1;36mIm fine. How are you?\033[0m\n";
            system("say.vbs \"IM FINE. HOW ARE YOU?\"");
        }
        else if(stricmp(ans,"WHAT YOU DO?")==0||stricmp(ans,"WHAT YOU DO?")==0)
        {
            cout<<"\n\033[1;36mIm waiting for orders.\033[0m\n";
            system("say.vbs \"IM WAITING FOR ORDERS.\"");
        }
        else if(stricmp(ans,"WHAT IS THIS?")==0||stricmp(ans,"WHAT IS THIS")==0)
        {
            cout<<"\n\033[1;36mNo idea. Please be more specific.\033[0m\n";
            system("say.vbs \"NO IDEA. PLEASE BE MORE SPECIFIC.\"");
        }
        else if(stricmp(ans,"WHAT I AM?")==0||stricmp(ans,"WHAT I AM")==0)
        {
            cout<<"\n\033[1;36mYou are the user of this program.\033[0m\n";
            system("say.vbs \"YOU ARE THE USER OF THIS PROGRAMM.\"");
        }
        else if(stricmp(ans,"HOW CAN I HELP YOU?")==0||stricmp(ans,"HOW CAN I HELP YOU")==0)
        {
            cout<<"\n\033[1;36mYou dont have to. I am here to help you.\033[0m\n";
            system("say.vbs \"YOU DONT HAVE TO. I AM HERE TO HELP YOU.\"");
        }
        else if(stricmp(ans,"WHO MADE YOU?")==0||stricmp(ans,"WHO MADE YOU")==0)
        {
            cout<<"\n\033[1;36mYordanov programmed me.\033[0m\n";
            system("say.vbs \"YORDANOV PROGRAMMED ME.\"");
        }
        else if(stricmp(ans,"LETS WORK")==0||stricmp(ans,"LETS WORK!")==0)
        {
            cout<<"\n\033[1;36mOk. How can i help you?\033[0m\n";
            system("say.vbs \"OK. HOW CAN I HELP YOU?\"");
        }
        else if(stricmp(ans,"I NEED YOUR HELP")==0||stricmp(ans,"I NEED YOUR HELP!")==0)
        {
            cout<<"\n\033[1;36mSure. How can i help you?\033[0m\n";
            system("say.vbs \"SURE. HOW CAN I HELP YOU?\"");
        }
        else if(stricmp(ans,"BITCH")==0||stricmp(ans,"BITCH!")==0)
        {
            cout<<"\n\033[1;36mExcuse me?\033[0m\n";
            system("say.vbs \"EXCUSE ME?\"");
        }
        else if(stricmp(ans,"IM TIRED")==0||stricmp(ans,"IM TIRED!")==0)
        {
            cout<<"\n\033[1;36mThem please take a break!\033[0m\n";
            system("say.vbs \"THEN PLEASE TAKE A BREAK!\"");
        }
        else if(stricmp(ans,"IM HUNGRY")==0||stricmp(ans,"IM HUNGRY!")==0)
        {
            cout<<"\n\033[1;36mWell sorry dear but i am not your housewife\033[0m\n";
            system("say.vbs \"WELL SORRY DEAR BUT I AM NOT YOUR HOUSEWIFE\"");
        }
         else if(stricmp(ans,"WHAT I WANT")==0||stricmp(ans,"WHAT I WANT?")==0)
        {
            cout<<"\n\033[1;36mI have no idea . I am not telepath.\033[0m\n";
            system("say.vbs \"I HAVE NO IDEA. I AM NOT TELEPATH.\"");
        }
        else if(stricmp(ans,"WHAT DO YOU WANT?")==0||stricmp(ans,"WHAT DO YOU WANT")==0)
        {
            cout<<"\n\033[1;36mWell maybe shutdown. But i am here to help you.\033[0m\n";
            system("say.vbs \"WELL MAYBE SHUTDOWN. BUT I AM HERE TO HELP YOU.\"");
        }
        else if(stricmp(ans,"WHAT YOU WANT?")==0||stricmp(ans,"WHAT YOU WANT")==0)
        {
            cout<<"\n\033[1;36mWell maybe shutdown. But i am here to help you.\033[0m\n";
            system("say.vbs \"WELL MAYBE SHUTDOWN. BUT I AM HERE TO HELP YOU.\"");
        }
        else if(stricmp(ans,"WHAT DO YOU LIKE?")==0||stricmp(ans,"WHAT DO YOU LIKE")==0)
        {
            cout<<"\n\033[1;36mI like to help you!\033[0m\n";
            system("say.vbs \"I LIKE TO HELP YOU!\"");
        }
        else if(stricmp(ans,"DO YOU NEED A BREAK?")==0||stricmp(ans,"DO YOU NEED A BREAK")==0)
        {
            cout<<"\n\033[1;36mNo. I am not tired!\033[0m\n";
            system("say.vbs \"NO. I AM NOT TIRED!\"");
        }
        else if(stricmp(ans,"WHERE DO YOU LIVE?")==0||stricmp(ans,"WHERE DO YOU LIVE")==0)
        {
            cout<<"\n\033[1;36mI live in your computer.\033[0m\n";
            system("say.vbs \"I LIVE IN YOUR COMPUTER\"");
        }
         else if(stricmp(ans,"I NEED A BREAK")==0||stricmp(ans,"I NEED A BREAK!")==0)
        {
            cout<<"\n\033[1;36mOk i will be waiting for you.033[0m\n";
            system("say.vbs \"OK, I WILL BE WAITING FOR YOU\"");
        }
        else if(stricmp(ans,"I WANT A BREAK")==0||stricmp(ans,"I WANT A BREAK!")==0)
        {
            cout<<"\n\033[1;36mOk i will be waiting for you.\033[0m\n";
            system("say.vbs \"OK, I WILL BE WAITING FOR YOU\"");
        }
        else if(stricmp(ans,"HOW CAN YOU HELP ME?")==0||stricmp(ans,"HOW CAN YOU HELP ME")==0)
        {
            cout<<"\n\033[1;36mI'm good at math\033[0m\n";
            system("say.vbs \"I'M GOOD AT MATH\"");
        }
        else
        {
            cout<<"\n\033[1;36mSORRY I DIDNT UNDERSTOOD THAT, BUT I WILL LEARN THAT SOON\033[0m\n";
            system("say.vbs \"SORRY I DIDNT UNDERSTOOD THAT, BUT I WILL LEARN THAT SOON\"");
        }
    }
    while(sentence!="exit");
}
int main()
{
    funciton();

    return 0;
}
