#ifndef BOTC_H
#define BOTC_H


class botc
{
    public:
        botc();
        virtual ~botc();

    protected:

    private:
};

#endif // BOTC_H
